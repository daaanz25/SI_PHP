package connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDatabase {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/si_php2";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "1";

    // Metode untuk mendapatkan koneksi ke database
    public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Koneksi ke database berhasil!");
        } catch (SQLException e) {
            System.err.println("Koneksi ke database gagal: " + e.getMessage());
        }
        return connection;
    }

    // Metode utama untuk menguji koneksi
    public static void main(String[] args) {
        Connection connection = ConnectDatabase.getConnection();
        if (connection != null) {
            System.out.println("Tes koneksi berhasil!");
        } else {
            System.out.println("Tes koneksi gagal!");
        }
    }
}
