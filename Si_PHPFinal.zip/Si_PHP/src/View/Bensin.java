/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import connect.ConnectDatabase;
import java.awt.Font;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/** 
 *
 * @author danz
 */
public class Bensin extends javax.swing.JFrame {
    
    /**     
     * Creates new form TampilanAwal
     */
    public Bensin () {
        initComponents();
        isiDataDariDatabase();
        jScrollPane1.setViewportView(DataBeras);
        DataBeras.revalidate();
        DataBeras.repaint();
                
       

        
        // Panggil fungsi untuk mengisi data dari database
        
        getContentPane().setBackground(new java.awt.Color(218, 233, 194));
         try {
            // Mengatur font khusus untuk jLabeltITitle1
            File fontStyle = new File("src/Font/Shrikhand-Regular.ttf");
            Font font1 = Font.createFont(Font.TRUETYPE_FONT, fontStyle).deriveFont(50f);
            Font font2 = Font.createFont(Font.TRUETYPE_FONT, fontStyle).deriveFont( 20f);
            TeksBulan.setFont(font1);
            TeksHargaBahanPokok.setFont(font1);
            TeksBeras.setFont(font2);
//            TeksGulaPasir.setFont(font2);
//            TeksMinyakGoreng.setFont(font2);            
        } catch (Exception e) {
            e.printStackTrace();
        }
         DataBeras.setModel(new DefaultTableModel(
            new Object [][] {},
            new String [] {
                "Merk", "Satuan", "Harga Bulan Lalu", "Harga Bulan Ini", "Indeks Inflasi"
            }
          ));
         

    }




    private void isiDataDariDatabase() {
    DefaultTableModel model = (DefaultTableModel) DataBeras.getModel();
    model.setRowCount(0);
    System.out.println("Debug - Periode yang dipilih:");
    System.out.println("Bulan: " + selectedBulanInt);
    System.out.println("Tahun: " + selectedTahunInt);

    String query = """
                   
        SELECT 
            m.nama_merk AS merk,
            m.satuan AS nama_satuan,
            h1.harga_merk AS harga_lalu,
            h2.harga_merk AS harga_sekarang,
            ROUND(((h2.harga_merk - h1.harga_merk)::numeric / h1.harga_merk * 100), 2) AS indeks_inflasi
        FROM 
            merk m
            JOIN harga h2 ON h2.id_merk = m.id
            JOIN harga h1 ON h1.id_merk = m.id 
            JOIN bahan b ON m.id_bahan = b.id
        WHERE 
            b.nama_bahan = 'Bensin' 
            AND EXTRACT(MONTH FROM h2.waktu) = ?
            AND EXTRACT(YEAR FROM h2.waktu) = ?
            AND h1.waktu = h2.waktu - interval '1 month'
        ORDER BY 
            m.nama_merk;
    """;

    try (Connection conn = ConnectDatabase.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        
        pstmt.setInt(1, selectedBulanInt);
        pstmt.setInt(2, selectedTahunInt);
        
        System.out.println("Parameter 1 (Bulan): " + selectedBulanInt);
        System.out.println("Parameter 2 (Tahun): " + selectedTahunInt);
        
        try (ResultSet rs = pstmt.executeQuery()) {
            int rowCount = 0;
            while (rs.next()) {
                rowCount++;
                System.out.println("Debug - Data baris " + rowCount + ":");
                System.out.println("Merk: " + rs.getString("merk"));
                System.out.println("Satuan: " + rs.getString("nama_satuan"));
                System.out.println("Harga Lalu: " + rs.getDouble("harga_lalu"));
                System.out.println("Harga Sekarang: " + rs.getDouble("harga_sekarang"));
                System.out.println("Indeks Inflasi: " + rs.getDouble("indeks_inflasi"));
                
                model.addRow(new Object[]{
                    rs.getString("merk"),
                    rs.getString("nama_satuan"),
                    formatRupiah(rs.getDouble("harga_lalu")),
                    formatRupiah(rs.getDouble("harga_sekarang")),
                    rs.getDouble("indeks_inflasi") + "%"
                });
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error mengambil data: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}

// Tambahkan method untuk format Rupiah
        private String formatRupiah(double nilai) {
            return String.format("Rp %,d", (int)nilai);
        }
    
 
    // </editor-fold>
@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        PanelJudul = new javax.swing.JPanel();
        TeksHargaBahanPokok = new javax.swing.JLabel();
        TeksBulan = new javax.swing.JLabel();
        Logo = new javax.swing.JLabel();
        kembali = new javax.swing.JButton();
        costumPanelRounded1 = new Pallate.CostumPanelRounded();
        TeksBeras = new javax.swing.JLabel();
        ContainerBundar = new javax.swing.JPanel();
        Bulatberas = new Pallate.CustomPaletteBundar();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        DataBeras = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(218, 233, 194));
        setMinimumSize(new java.awt.Dimension(1366, 768));
        setResizable(false);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });
        getContentPane().setLayout(null);

        jPanel2.setBackground(new java.awt.Color(36, 73, 39));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 130, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(130, -10, 40, 130);

        PanelJudul.setBackground(new java.awt.Color(218, 233, 194));
        PanelJudul.setLayout(new java.awt.BorderLayout(0, 1));

        TeksHargaBahanPokok.setBackground(new java.awt.Color(218, 233, 194));
        TeksHargaBahanPokok.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TeksHargaBahanPokok.setText("Harga Bahan Pokok");
        PanelJudul.add(TeksHargaBahanPokok, java.awt.BorderLayout.CENTER);

        TeksBulan.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TeksBulan.setText("Agustus 2024");
        PanelJudul.add(TeksBulan, java.awt.BorderLayout.PAGE_END);

        getContentPane().add(PanelJudul);
        PanelJudul.setBounds(170, 40, 1040, 160);

        Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/logo si php.png"))); // NOI18N
        getContentPane().add(Logo);
        Logo.setBounds(20, 30, 100, 83);

        kembali.setText("Kembali");
        kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kembaliActionPerformed(evt);
            }
        });
        getContentPane().add(kembali);
        kembali.setBounds(1210, 40, 120, 40);

        costumPanelRounded1.setBackground(new java.awt.Color(226, 232, 172));
        costumPanelRounded1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        costumPanelRounded1.setRoundedBottomLeft(10);
        costumPanelRounded1.setRoundedBottomRight(10);
        costumPanelRounded1.setRoundedTopLeft(10);
        costumPanelRounded1.setRoundedTopRight(10);

        TeksBeras.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TeksBeras.setText("Bensin");

        javax.swing.GroupLayout costumPanelRounded1Layout = new javax.swing.GroupLayout(costumPanelRounded1);
        costumPanelRounded1.setLayout(costumPanelRounded1Layout);
        costumPanelRounded1Layout.setHorizontalGroup(
            costumPanelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, costumPanelRounded1Layout.createSequentialGroup()
                .addContainerGap(647, Short.MAX_VALUE)
                .addComponent(TeksBeras, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(626, 626, 626))
        );
        costumPanelRounded1Layout.setVerticalGroup(
            costumPanelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(costumPanelRounded1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TeksBeras, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(costumPanelRounded1);
        costumPanelRounded1.setBounds(0, 230, 1370, 50);

        ContainerBundar.setBackground(new java.awt.Color(218, 233, 194));

        Bulatberas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Bensin.png"))); // NOI18N

        javax.swing.GroupLayout ContainerBundarLayout = new javax.swing.GroupLayout(ContainerBundar);
        ContainerBundar.setLayout(ContainerBundarLayout);
        ContainerBundarLayout.setHorizontalGroup(
            ContainerBundarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContainerBundarLayout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(Bulatberas, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(110, Short.MAX_VALUE))
        );
        ContainerBundarLayout.setVerticalGroup(
            ContainerBundarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContainerBundarLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(Bulatberas, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(141, Short.MAX_VALUE))
        );

        getContentPane().add(ContainerBundar);
        ContainerBundar.setBounds(0, 280, 490, 500);

        jPanel1.setBackground(new java.awt.Color(218, 233, 194));

        DataBeras.setBackground(new java.awt.Color(227, 227, 227));
        DataBeras.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Merk", "Satuan", "Harga Bulan Lalu", "Harga Bulan ini", "Indeks Inflasi"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        DataBeras.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(DataBeras);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(89, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 612, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(179, 179, 179))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(108, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(490, 280, 880, 510);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kembaliActionPerformed
        // TODO add your handling code here:
        Menu22 frame = new Menu22();
        frame.setVisible(true);
        this.dispose(); 
    }//GEN-LAST:event_kembaliActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        // TODO add your handling code here:
//        tblData.setModel (tbl);
    }//GEN-LAST:event_formComponentShown

    private String selectedBulan;
    private String selectedTahun;
    
    public void setTeksBulanTahun(String bulan, String tahun){
        this.selectedBulan = bulan;
        this.selectedTahun = tahun;
        TeksBulan.setText(bulan + " " + tahun);
        
    }
    
    public void updateTeksBulanTahun(){
        if (selectedBulan != null && selectedTahun != null) {
        TeksBulan.setText(selectedBulan + " " + selectedTahun);
    }
    }
    
    private int selectedBulanInt;
    private int selectedTahunInt;
    
    public void setBulanINT(int bulanint, int tahunint) {
        this.selectedBulanInt = bulanint;
        this.selectedTahunInt = tahunint;
        isiDataDariDatabase();
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Bensin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Bensin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Bensin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Bensin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Bensin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private Pallate.CustomPaletteBundar Bulatberas;
    private javax.swing.JPanel ContainerBundar;
    private javax.swing.JTable DataBeras;
    private javax.swing.JLabel Logo;
    private javax.swing.JPanel PanelJudul;
    private javax.swing.JLabel TeksBeras;
    private javax.swing.JLabel TeksBulan;
    private javax.swing.JLabel TeksHargaBahanPokok;
    private Pallate.CostumPanelRounded costumPanelRounded1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton kembali;
    // End of variables declaration//GEN-END:variables

}

