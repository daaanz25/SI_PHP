/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package si_php;

import View.TampilanAwal;
/**
 *
 * @author danz
 */
public class Si_PHP {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        TampilanAwal tampilanAwal = new TampilanAwal();
        tampilanAwal.setVisible(true); // Menampilkan TampilanAwal
    }
    
}
