package Pallate;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author danz
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import javax.swing.border.AbstractBorder;

public class CustomPaletteBundar extends JLabel{
    private BasicStroke stroke;
    private Color borderColor;


    
    public CustomPaletteBundar(){
        this(Color.BLACK, 1);
    } 
    
    public CustomPaletteBundar (Color borderColor, int borderWidht) {
        this.stroke = new BasicStroke(borderWidht);
        this.borderColor = borderColor;
        setSize(new Dimension(100,100));
        setPreferredSize(new Dimension(100,100));
        setOpaque(true);
        setHorizontalAlignment(JLabel.CENTER);
        setVerticalAlignment(JLabel.CENTER);
        setVisible(true);
        setBorder(new CustomBundar(borderColor, borderWidht));
        
    
    }    

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        int width = getWidth();
        int height = getHeight ();
        
        Ellipse2D.Double clip = new Ellipse2D.Double(0,0,width,height);
        g2d.setClip(clip);
        super.paintComponent(g2d);
        g2d.setStroke(stroke);
        g2d.draw(new Ellipse2D.Double(0,0, width-1, height-1));
    }
    

    public Color getBorderColor() {
        return borderColor;
    }

    public void setBorderColor(Color borderColor) {
        this.borderColor = borderColor;
        setBorder(new CustomBundar(borderColor, (int) stroke.getLineWidth()));
    }
    
    public int borderWidht(){
        return (int) stroke.getLineWidth();
    }
    
    public void setBorderWidht(int borderWidht){
        this.stroke = new BasicStroke(borderWidht);
        setBorder(new CustomBundar(borderColor, borderWidht));
        
        
    }
    
    private class CustomBundar extends AbstractBorder{
        private Color color;
        private BasicStroke stroke;
        private RenderingHints hints;
        
        public CustomBundar (Color color, int width){
            this.color = color;
            this.stroke = new BasicStroke(width);
            this.hints = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2d = (Graphics2D) g;
            Shape borderShape = new Ellipse2D.Double(x,y, width-1, height -1);
            
            g2d.setRenderingHints(hints);
            g2d.setColor(color);
            g2d.draw(borderShape);
            
      
        }
        
        
    }
        
    
}