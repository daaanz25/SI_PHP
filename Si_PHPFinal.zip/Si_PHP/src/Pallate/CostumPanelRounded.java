package Pallate;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Area;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JPanel;

public class CostumPanelRounded extends JPanel {

    private int roundedTopLeft = 0;
    private int roundedTopRight = 0;
    private int roundedBottomLeft = 0;
    private int roundedBottomRight = 0;

    public int getRoundedTopLeft() {
        return roundedTopLeft;
    }

    public void setRoundedTopLeft(int roundedTopLeft) {
        this.roundedTopLeft = roundedTopLeft;
        repaint();
    }

    public int getRoundedTopRight() {
        return roundedTopRight;
    }

    public void setRoundedTopRight(int roundedTopRight) {
        this.roundedTopRight = roundedTopRight;
        repaint();
    }

    public int getRoundedBottomLeft() {
        return roundedBottomLeft;
    }

    public void setRoundedBottomLeft(int roundedBottomLeft) {
        this.roundedBottomLeft = roundedBottomLeft;
        repaint();
    }

    public int getRoundedBottomRight() {
        return roundedBottomRight;
    }

    public void setRoundedBottomRight(int roundedBottomRight) {
        this.roundedBottomRight = roundedBottomRight;
        repaint();
    }

    public CostumPanelRounded() {
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics graphic) {
        // Membuat objek Graphics2D
        Graphics2D g2 = (Graphics2D) graphic.create();

        // Mengaktifkan anti-aliasing
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Mengatur warna latar belakang
        g2.setColor(getBackground());

        // Membuat Area dengan sudut membulat
        Area area = new Area(createRoundShape(getWidth(), getHeight()));

        // Mengisi area
        g2.fill(area);

        g2.dispose();
        super.paintComponent(graphic);
    }

    private Shape createRoundShape(int width, int height) {
        Area area = new Area(new Rectangle2D.Double(0, 0, width, height));

        if (roundedTopLeft > 0) {
            area.intersect(new Area(createRoundTopLeft(width, height, roundedTopLeft)));
        }
        if (roundedTopRight > 0) {
            area.intersect(new Area(createRoundTopRight(width, height, roundedTopRight)));
        }
        if (roundedBottomLeft > 0) {
            area.intersect(new Area(createRoundBottomLeft(width, height, roundedBottomLeft)));
        }
        if (roundedBottomRight > 0) {
            area.intersect(new Area(createRoundBottomRight(width, height, roundedBottomRight)));
        }

        return area;
    }

    private Shape createRoundTopLeft(int width, int height, int roundRadius) {
        int roundX = Math.min(width, roundRadius);
        int roundY = Math.min(height, roundRadius);

        Area area = new Area(new RoundRectangle2D.Double(0, 0, width, height, roundX, roundY));
        area.add(new Area(new Rectangle2D.Double(roundX / 2, 0, width - roundX / 2, height)));
        area.add(new Area(new Rectangle2D.Double(0, roundY / 2, width, height - roundY / 2)));

        return area;
    }

    private Shape createRoundTopRight(int width, int height, int roundRadius) {
        int roundX = Math.min(width, roundRadius);
        int roundY = Math.min(height, roundRadius);

        Area area = new Area(new RoundRectangle2D.Double(0, 0, width, height, roundX, roundY));
        area.add(new Area(new Rectangle2D.Double(0, 0, width - roundX / 2, height)));
        area.add(new Area(new Rectangle2D.Double(0, roundY / 2, width, height - roundY / 2)));

        return area;
    }

    private Shape createRoundBottomLeft(int width, int height, int roundRadius) {
        int roundX = Math.min(width, roundRadius);
        int roundY = Math.min(height, roundRadius);

        Area area = new Area(new RoundRectangle2D.Double(0, 0, width, height, roundX, roundY));
        area.add(new Area(new Rectangle2D.Double(roundX / 2, 0, width - roundX / 2, height)));
        area.add(new Area(new Rectangle2D.Double(0, 0, width, height - roundY / 2)));

        return area;
    }

    private Shape createRoundBottomRight(int width, int height, int roundRadius) {
        int roundX = Math.min(width, roundRadius);
        int roundY = Math.min(height, roundRadius);

        Area area = new Area(new RoundRectangle2D.Double(0, 0, width, height, roundX, roundY));
        area.add(new Area(new Rectangle2D.Double(0, 0, width - roundX / 2, height)));
        area.add(new Area(new Rectangle2D.Double(0, 0, width, height - roundY / 2)));

        return area;
    }
}
