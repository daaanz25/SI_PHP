package Admin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class Create_EditData extends JFrame {

    private Connection connection;
    private JTextField txtHarga, txtWaktu, txtMerk;
    private JComboBox<String> comboBahan, comboKategoriBahan, comboSatuan;
    private JTable tableData;
    private DefaultTableModel tableModel;

    public Create_EditData() {
        initComponents();
        connectToDatabase();
        loadComboBahan();
        loadComboKategoriBahan();
        loadComboSatuan();
        loadData();
        initializeBackButton();
    }
    private JButton backButton; 
    private JPanel panelForm;
   private void initializeBackButton() {
    
    backButton = new JButton("Kembali");
    backButton.addActionListener((ActionEvent e) -> {
        dispose();
        Admin_Menu22 newFrame = new Admin_Menu22();
        newFrame.setVisible(true);
    });
    
    // Create a panel for the back button with FlowLayout aligned to the right
    JPanel backButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    backButtonPanel.add(backButton);
    
    // Add the panel to the NORTH position of the BorderLayout
    add(backButtonPanel, BorderLayout.NORTH);
    
    // Move the form panel to be below the back button
    JPanel mainContent = new JPanel(new BorderLayout());
    mainContent.add(panelForm, BorderLayout.NORTH);
    mainContent.add(new JScrollPane(tableData), BorderLayout.CENTER);
    
    // Add the main content to the CENTER of the frame
    add(mainContent, BorderLayout.CENTER);
}

    private void connectToDatabase() {
        try {
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/si_php2", "postgres", "1");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error connecting to database: " + e.getMessage());
        }
    }

    private void initComponents() {
        setTitle("Admin Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        panelForm = new JPanel(new GridLayout(6, 2, 5, 5));

        panelForm.add(new JLabel("Nama Bahan:"));
        comboBahan = new JComboBox<>();
        panelForm.add(comboBahan);

        panelForm.add(new JLabel("Kategori Bahan:"));
        comboKategoriBahan = new JComboBox<>();
        panelForm.add(comboKategoriBahan);

        panelForm.add(new JLabel("Merk:"));
        txtMerk = new JTextField();
        panelForm.add(txtMerk);

        panelForm.add(new JLabel("Harga:"));
        txtHarga = new JTextField();
        panelForm.add(txtHarga);

        panelForm.add(new JLabel("Waktu (YYYY-MM-DD):"));
        txtWaktu = new JTextField();
        panelForm.add(txtWaktu);

        panelForm.add(new JLabel("Satuan:"));
        comboSatuan = new JComboBox<>();
        panelForm.add(comboSatuan);

        JPanel panelButtons = new JPanel(new FlowLayout());

        JButton btnCreate = new JButton("Create");
        btnCreate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createData();
            }
        });
        panelButtons.add(btnCreate);

        JButton btnUpdate = new JButton("Update");
        btnUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateData();
            }
        });
        panelButtons.add(btnUpdate);

        JButton btnDelete = new JButton("Delete");
        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteData();
            }
        });
        panelButtons.add(btnDelete);

        JButton btnRead = new JButton("Read");
        btnRead.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadData();
            }
        });

        tableModel = new DefaultTableModel(new String[]{"ID", "Nama Bahan", "Merk", "Harga", "Waktu", "Satuan"}, 0);
        tableData = new JTable(tableModel);

        add(panelForm, BorderLayout.NORTH);
        add(new JScrollPane(tableData), BorderLayout.CENTER);
        add(panelButtons, BorderLayout.SOUTH);
    }
    

    private void loadComboBahan() {
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT nama_bahan FROM bahan");
            while (resultSet.next()) {
                comboBahan.addItem(resultSet.getString("nama_bahan"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading bahan: " + e.getMessage());
        }
    }

    private void loadComboKategoriBahan() {
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT nama_kategori FROM kategori_barang;");
            while (resultSet.next()) {
                comboKategoriBahan.addItem(resultSet.getString("nama_kategori"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading kategori bahan: " + e.getMessage());
        }
    }

    private void loadComboSatuan() {
        comboSatuan.addItem("Karung");
        comboSatuan.addItem("Liter");
        comboSatuan.addItem("Batang");
        comboSatuan.addItem("Sak");
        comboSatuan.addItem("Meter");
        comboSatuan.addItem("3 kilo");
    }

    private void loadData() {
        tableModel.setRowCount(0);
        try (Statement statement = connection.createStatement()) {
            String query = "SELECT harga.id, bahan.nama_bahan, merk.nama_merk, harga.harga_merk, harga.waktu, merk.satuan " +
                           "FROM harga " +
                           "JOIN merk ON harga.id_merk = merk.id " + 
                           "JOIN bahan ON merk.id_bahan = bahan.id " + 
                           "ORDER BY harga.id";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                tableModel.addRow(new Object[]{
                        resultSet.getInt("id"),
                        resultSet.getString("nama_bahan"),
                        resultSet.getString("nama_merk"),
                        resultSet.getDouble("harga_merk"),
                        resultSet.getDate("waktu"),
                        resultSet.getString("satuan")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }

    private void createData() {
        String namaBahan = (String) comboBahan.getSelectedItem();
        String kategoriBahan = (String) comboKategoriBahan.getSelectedItem();
        String merk = txtMerk.getText();
        String harga = txtHarga.getText();
        String waktu = txtWaktu.getText();
        String satuan = (String) comboSatuan.getSelectedItem();

        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO merk (id_bahan, id_kategori_barang, nama_merk, satuan) " +
                "VALUES ((SELECT id FROM bahan WHERE nama_bahan = ?), (SELECT id FROM kategori_barang WHERE nama_kategori = ?), ?, ?) RETURNING id")) {
            statement.setString(1, namaBahan);
            statement.setString(2, kategoriBahan);
            statement.setString(3, merk);
            statement.setString(4, satuan);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int idMerk = resultSet.getInt("id");
                try (PreparedStatement hargaStatement = connection.prepareStatement(
                        "INSERT INTO harga (harga_merk, waktu, id_merk) VALUES (?, ?, ?)")) {
                    hargaStatement.setDouble(1, Double.parseDouble(harga));
                    hargaStatement.setDate(2, Date.valueOf(waktu));
                    hargaStatement.setInt(3, idMerk);
                    hargaStatement.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
                    loadData();
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error creating data: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Harga harus berupa angka valid.");
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Waktu harus dalam format YYYY-MM-DD.");
        }
    }
    
    
    private void updateData() {
    int selectedRow = tableData.getSelectedRow();
    if (selectedRow >= 0) {
        int hargaId = (int) tableModel.getValueAt(selectedRow, 0);
        String namaBahan = comboBahan.getSelectedItem().toString().trim();
        String kategoriBahan = comboKategoriBahan.getSelectedItem().toString().trim();
        String merk = txtMerk.getText().trim();
        String hargaStr = txtHarga.getText().trim();
        String waktuStr = txtWaktu.getText().trim();
        String satuan = comboSatuan.getSelectedItem().toString().trim();

        try {
            double harga = Double.parseDouble(hargaStr);
            Date waktu = Date.valueOf(waktuStr);

            connection.setAutoCommit(false);

            // First, get the merk_id from harga table
            String getMerkIdSql = "SELECT id_merk FROM harga WHERE id = ?";
            int merkId;
            try (PreparedStatement stmt = connection.prepareStatement(getMerkIdSql)) {
                stmt.setInt(1, hargaId);
                ResultSet rs = stmt.executeQuery();
                if (!rs.next()) {
                    throw new SQLException("Harga record not found");
                }
                merkId = rs.getInt("id_merk");
            }

            // Update merk table
            String sqlMerk = "UPDATE merk SET id_bahan = (SELECT id FROM bahan WHERE nama_bahan = ?), " +
                           "id_kategori_barang = (SELECT id FROM kategori_barang WHERE nama_kategori = ?), " +
                           "nama_merk = ?, satuan = ? WHERE id = ?";
            
            // Update harga table
            String sqlHarga = "UPDATE harga SET harga_merk = ?, waktu = ? WHERE id = ?";

            try (PreparedStatement stmtMerk = connection.prepareStatement(sqlMerk);
                 PreparedStatement stmtHarga = connection.prepareStatement(sqlHarga)) {
                
                // Update merk first
                stmtMerk.setString(1, namaBahan);
                stmtMerk.setString(2, kategoriBahan);
                stmtMerk.setString(3, merk);
                stmtMerk.setString(4, satuan);
                stmtMerk.setInt(5, merkId);
                int merkUpdateResult = stmtMerk.executeUpdate();

                // Update harga
                stmtHarga.setDouble(1, harga);
                stmtHarga.setDate(2, waktu);
                stmtHarga.setInt(3, hargaId);
                int hargaUpdateResult = stmtHarga.executeUpdate();

                if (merkUpdateResult > 0 && hargaUpdateResult > 0) {
                    connection.commit();
                    JOptionPane.showMessageDialog(this, "Data updated successfully!");
                    loadData();
                } else {
                    throw new SQLException("Update failed: No rows affected");
                }
            }
        } catch (SQLException | IllegalArgumentException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "Error updating data: " + e.getMessage());
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a row to update.");
    }
}

private void deleteData() {
    int selectedRow = tableData.getSelectedRow();
    if (selectedRow >= 0) {
        int hargaId = (int) tableModel.getValueAt(selectedRow, 0);

        int confirmation = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete the selected item?", "Confirm Deletion",
                JOptionPane.YES_NO_OPTION);

        if (confirmation == JOptionPane.YES_OPTION) {
            try {
                connection.setAutoCommit(false);

                // First, get the merk_id from harga table
                String getMerkIdSql = "SELECT id_merk FROM harga WHERE id = ?";
                int merkId;
                try (PreparedStatement stmt = connection.prepareStatement(getMerkIdSql)) {
                    stmt.setInt(1, hargaId);
                    ResultSet rs = stmt.executeQuery();
                    if (!rs.next()) {
                        throw new SQLException("Harga record not found");
                    }
                    merkId = rs.getInt("id_merk");
                }

                // Delete from harga first
                String sqlDeleteHarga = "DELETE FROM harga WHERE id = ?";
                String sqlDeleteMerk = "DELETE FROM merk WHERE id = ?";

                try (PreparedStatement stmtDeleteHarga = connection.prepareStatement(sqlDeleteHarga);
                     PreparedStatement stmtDeleteMerk = connection.prepareStatement(sqlDeleteMerk)) {

                    stmtDeleteHarga.setInt(1, hargaId);
                    int rowsAffectedHarga = stmtDeleteHarga.executeUpdate();

                    if (rowsAffectedHarga > 0) {
                        stmtDeleteMerk.setInt(1, merkId);
                        int rowsAffectedMerk = stmtDeleteMerk.executeUpdate();

                        if (rowsAffectedMerk > 0) {
                            connection.commit();
                            JOptionPane.showMessageDialog(this, "Data deleted successfully!");
                            loadData();
                        } else {
                            throw new SQLException("Failed to delete from merk table");
                        }
                    } else {
                        throw new SQLException("Failed to delete from harga table");
                    }
                }
            } catch (SQLException e) {
                try {
                    connection.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                JOptionPane.showMessageDialog(this, "Error deleting data: " + e.getMessage());
            } finally {
                try {
                    connection.setAutoCommit(true);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a row to delete.");
    }
}


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Create_EditData().setVisible(true));
    }
}
